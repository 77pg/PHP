<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormController extends PowHomeController
{
    // Request資料型態，invoke不能覆寫，所以自定義process
    function process(Request $request){
        $a =$request->a;
        $b =$request->b;
        $op =$request->op;
        // 物件導向
        // 如果等於pow，則去繼承PowHomeController
        // 如果不是，則去invoke HomeController
        if( $op == 'pow'){
            return parent::pow($a,$b);
        }else{
            return parent::__invoke($op,$a,$b);
        }
    }
}
