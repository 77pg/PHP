<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    
    function __invoke($op,$a,$b){
        switch($op){
            case 'add':
                $ans = $a+$b;
                $op ='+';
                break;
            case 'sub':
                $ans = $a-$b;
                $op ='-';
                break;
            case 'mul':
                $ans = $a*$b;
                $op ='×';
                break;
            case 'div':
                $ans = $a/$b;
                $op ='/';
                break;
        }
        return
            view('home')
            ->with('a',$a)
            ->with('op',$op)
            ->with('b',$b)
            ->with('answer',$ans);
    }
    // function pow( $a, $b){
    //     return view('home')
    //         ->with('a', $a)
    //         ->with('op','^')
    //         ->with('b', $b)
    //         ->with('answer', pow($a,$b));
    // }
}

// 繼承HomeController
class PowHomeController extends HomeController{
    function pow( $a, $b){
        return view('home')
            ->with('a', $a)
            ->with('op','^')
            ->with('b', $b)
            ->with('answer', pow($a,$b));
    }
}