<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- http://localhost/HelloLaravel/public/form -->
    <form method="post">
    <!-- 防止跨域攻擊 -->
    @csrf
    Number A : <input name="a"><p>
    Number B : <input name="b"><p>
    Operator : <input name="op"><p>
    <input type="submit">
</body>
</html>