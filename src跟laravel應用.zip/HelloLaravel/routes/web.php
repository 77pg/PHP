<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// 變成呼叫HomeController，也可以用use
// 複製namespace App\Http\Controllers;放置最上方加入
// 如果是自己寫的function，不要呼叫invoke，所以改為陣列，第二個值為pow
// 先後順序有差，因為pow在op裡，先到先做，放後面會被攔截，所以放置第一個
// 平方http://localhost/HelloLaravel/public/pow/4/3
// Route::get('pow/{a}/{b}',[HomeController::class,'pow']);
Route::get('pow/{a}/{b}',[PowHomeController::class,'pow']);
Route::get('{op}/{a}/{b}',HomeController::class);

// http://localhost/HelloLaravel/public/form
Route::view('/form','form');

// 按下按鈕
// Route::post('/form',FormController::class);
// 輸入a按下按鈕可見a
// use Illuminate\Http\Request;
// Route::post('/form',function(Request $request){
    //     echo $request->a;
    // });

Route::post('/form',[FormController::class,'process']);




