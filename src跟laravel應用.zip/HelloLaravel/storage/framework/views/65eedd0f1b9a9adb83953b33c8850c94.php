<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php echo e($a); ?> <?php echo e($op); ?> <?php echo e($b); ?> = <?php echo e($answer); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\HelloLaravel\resources\views/home.blade.php ENDPATH**/ ?>