<?php
namespace Happy\hi\ok1;//類似給一個虛擬資料夾，斜線是路徑概念

class Hello{
    function __toString(){
        return 'AAA<br>';
    }
}