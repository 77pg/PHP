<?php
namespace Happy\hi\ok;

class Hello{
    function __toString () {
        return 'BBB<br>';
    }
}