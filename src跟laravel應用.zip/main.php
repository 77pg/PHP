<?php
// 要require很多的php，用composer與autoload
// (一個檔案只有一個class、class名稱跟檔名要一致、class名稱第一個字大寫)
// namespace後面要真正的路徑資料夾，用src資料夾
require('a.php');
require('b.php');
//通常用公司網域名稱，用as縮短名稱
//如果沒有as，則是用路徑最後的class名稱
use Happy\hi\ok1\Hello;
use Happy\hi\ok\Hello as B;

echo new Hello();
echo new B();