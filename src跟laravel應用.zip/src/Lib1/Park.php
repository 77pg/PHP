<?php
namespace Lib1;
use Lib2\Tree;

class Park{
    function __toString() {
        return "This is Park\n";
    }
   function info(){
    $tree= new Tree(20);
    echo "{$tree->count} trees in the park<br>";
   }
}