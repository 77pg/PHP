<?php session_start(); ?>
<?php
//http://localhost/老師版/s1.php
$_session['name']='David';
echo $_session['name'];
?>