<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

require_once("db.php");
// 接收表單提交的電子郵件地址
$email = $_REQUEST['email'];
// 生成隨機的重設密碼連結
$resetToken = uniqid();

$stmt = $mysqli->prepare("CALL emailregister(?)");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($result);
$stmt->fetch();
$stmt->close();


// 處理電子郵件地址的驗證和過濾，以防止安全問題

// 執行資料庫查詢以檢查電子郵件是否存在於資料庫中

// 假設查詢結果為存在
if ($result === "email已存在") {
    // 建立新的 PHPMailer 實例
    $mail = new PHPMailer();

    $mail->CharSet = 'UTF-8';
    // 設定 SMTP 伺服器的相關設定
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'charites00@gmail.com'; // 替換為你的 Gmail 信箱
    $mail->Password = 'mzdsibubtxwsltea'; // 替換為你的 Gmail 安全性第三方應用程式的 密碼
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // 設定寄件人和收件人
    $mail->setFrom('charites00@gmail.com', 'charites'); // 替換為你的寄件人信箱和名稱
    $mail->addAddress($email, '收件人'); // 使用表單提交的電子郵件和收件人名稱

    // 更新 userinfo 資料表中的 reset_token 和 reset_token_valid 欄位
    $updateSql = "UPDATE userinfo SET reset_token = '$resetToken', reset_token_valid = 1 WHERE email = '$email'";
    $mysqli->query($updateSql);

    // 發送郵件包含重設密碼連結
    $subject = "=?UTF-8?B?" . base64_encode('charites低調廚房，會員認證信函:') . "?="; //信件標題，解決亂碼問題
    $mail->Subject = $subject;
    // $mail->Subject = '我們是charites低調廚房';
    $resetLink = 'http://localhost/resetpwd.html?reset_token=' . $resetToken;
    $mail->Body = '您在我們這邊忘記密碼，以下是重設密碼的連結：' . $resetLink;

    // // 設定郵件主題和內容
    // $mail->Subject = '我們是charites低調廚房';
    // $mail->Body = '您在我們這邊忘記密碼，以下是重設密碼的連結' . $resetlink;

    // 發送郵件
    if (!$mail->send()) {
        echo '郵件發送失敗: ' . $mail->ErrorInfo;
    } else {
        echo '郵件已成功發送';
    }
} else {
    echo "信箱不存在於資料庫中";
}
// 關閉資料庫連線
$mysqli->close();
