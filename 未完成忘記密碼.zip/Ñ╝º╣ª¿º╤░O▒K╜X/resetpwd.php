<?php
require_once("db.php");
// 從 URL 參數中獲取重設密碼的驗證標識
$reset_token = $_REQUEST['reset_token'];
$newPassword = $_REQUEST['new_password'];

// 檢查資料庫中的 reset_tokens 表格，驗證連結的有效性
$sql = "SELECT reset_token FROM userinfo WHERE reset_token = '$reset_token' AND reset_token_valid = 1";

$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    
    // // 驗證標識有效，取得對應的使用者 ID
    // $row = $result->fetch_assoc();
    // $userId = $row['uid'];

    // 從表單中獲取新密碼

    
    // // 標記驗證標識為無效
    // $markInvalidSql = "UPDATE reset_token SET reset_token_valid = 0 WHERE reset_token = '$reset_token'";
    // $mysqli->query($markInvalidSql);
    
    if($newPassword!=''){
            // 更新資料庫中的密碼
            $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
            // $updateSql = "UPDATE userinfo SET pwd = '$hashedPassword' WHERE uid = $userId";
            $updateSql = "UPDATE userinfo SET pwd = '$hashedPassword', reset_token ='', reset_token_valid = 0 WHERE reset_token = '$reset_token'";
            $mysqli->query($updateSql);
            // 顯示成功訊息或進行其他處理
            echo '密碼已成功重設';
            // header("location:login.php");
        }else{
            echo '請輸入新密碼';
        }
    }
    else {
        // 顯示錯誤訊息或進行其他處理
        echo '無效標籤';
    }
     

// 關閉資料庫連線
$mysqli->close();
?>